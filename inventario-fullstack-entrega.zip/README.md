
# Sistema de Inventario Fullstack

## Descripción
Aplicación web fullstack para la gestión de inventario con autenticación de usuarios, CRUD de productos y control de stock.

## Tecnologías
Frontend: React + Bootstrap  
Backend: Node.js + Express  
Base de datos: MySQL  

## Estructura
frontend/
backend/
db/
docs/

## Ejecución
Backend:
npm install
npm start

Frontend:
npm install
npm start

## Autora
Bertha Mero
